#ifndef REORGANIZACAO_H
#define REORGANIZACAO_H

void quickSort(int vetor[], int inicio, int fim);

#endif