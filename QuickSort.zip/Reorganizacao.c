#include "Reorganizacao.h"
#include "Particionamento.h"

void quickSort(int vetor[], int inicio, int fim) {
    
    if (inicio < fim)  {
        int p = particionar(vetor, inicio, fim);

        quickSort(vetor, inicio, p - 1);
        quickSort(vetor, p + 1, fim);
    }
}
