#ifndef PARTICIONAMENTO_H
#define PARTICIONAMENTO_H

int particionar(int vetor[], int inicio, int fim);

#endif
