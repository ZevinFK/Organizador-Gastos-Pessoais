#include <stdio.h>
#include "Reorganizacao.h"

int main()
{
    int vetor[] = {8, 3, 1, 7, 0, 10, 2};

    int tamanho = sizeof(vetor) / sizeof(vetor[0]);

    quickSort(vetor, 0, tamanho - 1);

    printf("Vetor ordenado:\n");

    for (int i = 0; i < tamanho; i++){
        printf("%d ", vetor[i]);
    }

    return 0;
}
